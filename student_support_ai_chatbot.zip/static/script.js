const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const messages = document.getElementById("messages");
const welcome = document.getElementById("welcome");
const sendBtn = document.getElementById("sendBtn");
const sessionId = "student-" + Math.random().toString(36).slice(2);

function addMessage(role, text) {
  welcome.style.display = "none";
  messages.style.display = "flex";
  const item = document.createElement("div");
  item.className = "message " + role;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "Y" : "✦";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  item.append(avatar, bubble);
  messages.appendChild(item);
  messages.scrollTop = messages.scrollHeight;
  return item;
}

async function sendMessage(text) {
  const clean = text.trim();
  if (!clean) return;
  addMessage("user", clean);
  input.value = "";
  sendBtn.disabled = true;
  const waiting = addMessage("assistant", "Thinking...");
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message: clean, session_id: sessionId})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed");
    waiting.querySelector(".bubble").textContent = data.answer;
  } catch (error) {
    waiting.querySelector(".bubble").textContent = "Sorry, something went wrong. Please try again.";
  } finally {
    sendBtn.disabled = false;
    input.focus();
    messages.scrollTop = messages.scrollHeight;
  }
}

form.addEventListener("submit", e => { e.preventDefault(); sendMessage(input.value); });
document.querySelectorAll("[data-prompt]").forEach(btn => {
  btn.addEventListener("click", () => sendMessage(btn.dataset.prompt));
});
document.getElementById("newChat").addEventListener("click", () => {
  messages.innerHTML = "";
  messages.style.display = "none";
  welcome.style.display = "block";
});
input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); }
});
