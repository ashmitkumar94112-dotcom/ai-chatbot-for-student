# Student Support AI Chatbot

A beginner-friendly full-stack student help chatbot with:
- Frontend: HTML, CSS and JavaScript
- Backend: Python Flask REST API
- Database: SQLite chat history
- Local knowledge retrieval: TF-IDF similarity using scikit-learn
- Optional AI answers: OpenAI API (only if an API key is configured)

## 1. Requirements
Install Python 3.10 or newer.

## 2. Setup

Open a terminal inside this project folder:

```bash
python -m venv venv
```

Activate it:

**Windows**
```bash
venv\\Scripts\\activate
```

**macOS/Linux**
```bash
source venv/bin/activate
```

Install packages:

```bash
pip install -r requirements.txt
```

## 3. Run

```bash
python app.py
```

Open this address in your browser:

http://127.0.0.1:5000

## 4. Optional OpenAI setup
Copy `.env.example` to `.env`, then add your API key:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-4.1-mini
```

Restart the Flask server. Without an API key, the project still works using the local FAQ knowledge base.

## 5. Customize college information
Edit `data/knowledge_base.json`. Add entries in this format:

```json
{
  "question": "How do I apply for a hostel?",
  "answer": "Contact the hostel office for the current application process."
}
```

Use accurate, approved college information. Do not put private student records, passwords, OTPs or confidential data in the knowledge base.

## 6. API endpoints
- `GET /api/health` — checks whether the backend is running
- `POST /api/chat` — accepts `{ "message": "...", "session_id": "..." }`
- `GET /api/history?session_id=...` — returns recent chat history for a session

## 7. Project structure

```text
student_support_ai_chatbot/
├── app.py
├── chatbot.py
├── requirements.txt
├── .env.example
├── README.md
├── data/
│   └── knowledge_base.json
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js
```

## Important
This is a college-project starter/demo, not a production student information system. The demo does not authenticate users or connect to a real college ERP. Before deployment, add login, authorization, HTTPS, input limits, secure secret management, database backups and privacy controls. Never expose student marks, fees or attendance without verified authentication and authorization.
