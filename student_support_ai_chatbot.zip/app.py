import os, sqlite3
from datetime import datetime
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from chatbot import get_answer

load_dotenv()
app = Flask(__name__)
DB_PATH = os.path.join("data", "chat_history.db")

def init_db():
    os.makedirs("data", exist_ok=True)
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/chat", methods=["POST"])
def chat():
    payload = request.get_json(silent=True) or {}
    message = (payload.get("message") or "").strip()
    session_id = (payload.get("session_id") or "guest").strip()
    if not message:
        return jsonify({"error": "Please enter a message."}), 400

    answer = get_answer(message)
    now = datetime.utcnow().isoformat()
    with sqlite3.connect(DB_PATH) as con:
        con.executemany(
            "INSERT INTO messages(session_id, role, message, created_at) VALUES (?, ?, ?, ?)",
            [(session_id, "user", message, now), (session_id, "assistant", answer, now)]
        )
    return jsonify({"answer": answer})

@app.route("/api/history", methods=["GET"])
def history():
    session_id = request.args.get("session_id", "guest")
    with sqlite3.connect(DB_PATH) as con:
        rows = con.execute(
            "SELECT role, message, created_at FROM messages WHERE session_id=? ORDER BY id DESC LIMIT 30",
            (session_id,)
        ).fetchall()
    rows.reverse()
    return jsonify([{"role": r[0], "message": r[1], "created_at": r[2]} for r in rows])

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "service": "Student Support AI Chatbot"})

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
