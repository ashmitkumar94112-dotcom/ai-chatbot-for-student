import os, json
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

KB_FILE = Path("data/knowledge_base.json")

def load_knowledge():
    with open(KB_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def retrieve_answer(question):
    items = load_knowledge()
    questions = [item["question"] for item in items]
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(questions + [question])
    scores = cosine_similarity(matrix[-1], matrix[:-1]).flatten()
    best = int(scores.argmax())
    if scores[best] < 0.12:
        return None
    return items[best]["answer"]

def get_answer(question):
    # Optional OpenAI response. If no API key is configured, use local FAQ retrieval.
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            context = retrieve_answer(question) or "No matching college policy was found."
            response = client.responses.create(
                model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
                instructions=(
                    "You are a helpful student support assistant. Answer clearly and simply. "
                    "Use the provided college information when relevant. Do not invent official "
                    "dates, fees, marks, attendance rules, or policies. If information is missing, "
                    "tell the student to contact the college office."
                ),
                input=f"College information:\n{context}\n\nStudent question:\n{question}"
            )
            return response.output_text
        except Exception:
            pass

    answer = retrieve_answer(question)
    if answer:
        return answer
    return (
        "I couldn't find a reliable answer in the sample college knowledge base. "
        "Please contact your faculty coordinator or college office for confirmation. "
        "You can also add the relevant information to data/knowledge_base.json."
    )
